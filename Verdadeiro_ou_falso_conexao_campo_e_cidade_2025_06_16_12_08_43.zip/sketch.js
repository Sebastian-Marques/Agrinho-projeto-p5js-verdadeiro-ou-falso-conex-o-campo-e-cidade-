function setup() {
  createCanvas(1000,1000);
}

function draw() {
  background(200,200);
} 
const perguntas = [
  "A cidade faz o fornecimento de tecnologias, e mercado para melhoria das atividades agricolas?",
  "O turismo rural é uma forma de fortalecer a conexão cultural e econômica entre campo e cidade ?",
  "A agricultura não é importante para o abastecimento de alimentos e materia prima do espaço urbano?", 
  "O meio rural não tem consequencias para o meio ambiente, como poluição,desmatamento,queimadas.", 
  "A cidade e o campo estão interligados, e precisam de um ao outro para manter o equilibrio financeiro, cultural, tecnologica, etc.", 
  "A produção de alimentos no campo não tem impacto direto na variedade e no custo de produtos no mercado",
   "A popularização de alimentos orgânicos nos meios urbanos em feiras e comércios, mostra a conexão presente no campo e cidade",
  "a biodiversidade presente no campo influência na qualidade da vida na cidade, clima, água, qualidade do ar",
  "O campo disponibiliza não somente alimentos, mas também produtos artesanais",
  "A cultura e as celebrações do campo não tem influência para a formação da indentidade cultural brasileira",
];

const respostas = [
  true,
  true,
  false, 
  false, 
  true, 
  false,
  true,
  true,
  true,
 false,
]; 
let perguntaAtual = 0;
let contador = 0;

function setup() {
  createCanvas(1000, 500);
  button1 = createButton('✅');
  button2 = createButton('❌');
  button1.position(300, 320);
  button2.position(400, 320);
  button1.mousePressed(verdade);
  button2.mousePressed(mentira);
  button1.style('padding: 10px 20px');
  button2.style('padding: 10px 20px');
}

function draw() {
  background('#E8FF09');
  textSize(16);
  textAlign(CENTER);
  text(perguntas[perguntaAtual], 450, 200);
} 
function verdade() {
  if (respostas[perguntaAtual]) {
    contador++;
  }
  proximaPergunta();
}

function mentira() {
  if (!respostas[perguntaAtual]) {
    contador++;
  }
  proximaPergunta();
}

function proximaPergunta() {
  perguntaAtual = (perguntaAtual + 1) % perguntas.length;
  if (perguntaAtual == 0) {
    alert("Fim do jogo! Sua pontuação é " + contador + " de " + perguntas.length);
    contador = 0;
  }
}